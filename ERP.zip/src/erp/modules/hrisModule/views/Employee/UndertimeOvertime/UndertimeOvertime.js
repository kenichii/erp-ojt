import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
import UndertimeOvertimeList from '../../../components/Employee/UndertimeOvertimeList/UndertimeOvertimeList.vue';
let UndertimeOvertime = class UndertimeOvertime extends Vue {
};
UndertimeOvertime = tslib_1.__decorate([
    Component({
        name: 'UndertimeOvertime',
        components: {
            UndertimeOvertimeList
        }
    })
], UndertimeOvertime);
export default UndertimeOvertime;
//# sourceMappingURL=UndertimeOvertime.js.map