<template>
    <section id="userInformation">
        <ProfileInformation/>
        <BusinessInformation/>
        <ContactInformation/>
    </section>
</template>

<script lang='ts' src='./UserInformation.ts'/>
