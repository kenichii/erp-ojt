import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
import FillingOfUndertimeAndOvertime from '../../../components/Employee/FillingOfUndertimeAndOvertime/FillingOfUndertimeAndOvertime.vue';
let FillingOfUndertimeAndOverTime = class FillingOfUndertimeAndOverTime extends Vue {
};
FillingOfUndertimeAndOverTime = tslib_1.__decorate([
    Component({
        name: 'FillingOfUndertime',
        components: {
            FillingOfUndertimeAndOvertime,
        },
    })
], FillingOfUndertimeAndOverTime);
export default FillingOfUndertimeAndOverTime;
//# sourceMappingURL=FillingOfUndertimeAndOverTime.js.map