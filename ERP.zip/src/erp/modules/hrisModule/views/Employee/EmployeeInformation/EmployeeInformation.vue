<template>
    <section id="employeeInformation">
        <ProfileInformation/>
        <ContactInformation/>
        <EducationalBackground/>
        <EmploymentHistory/>
        <MedicalIds/>
        <Skills/>
    </section>
</template>

<script lang='ts' src='./EmployeeInformation.ts'/>
