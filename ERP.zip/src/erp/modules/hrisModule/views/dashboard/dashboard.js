import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
let DashBoard = class DashBoard extends Vue {
};
DashBoard = tslib_1.__decorate([
    Component({
        name: 'DashBoard',
        components: {},
    })
], DashBoard);
export default DashBoard;
//# sourceMappingURL=dashboard.js.map