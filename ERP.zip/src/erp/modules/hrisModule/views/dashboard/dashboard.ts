import {Component, Vue} from 'vue-property-decorator';

@Component({
    name: 'DashBoard',
    components: {},
})
export default class DashBoard extends Vue {

}
