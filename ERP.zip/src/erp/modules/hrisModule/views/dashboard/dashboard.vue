<template>
    <div>
        <p>
            dashboard Here
        </p>
    </div>
</template>

<script lang='ts' src='./dashboard.ts'/>