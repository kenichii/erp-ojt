import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
let EmployeeManagement = class EmployeeManagement extends Vue {
};
EmployeeManagement = tslib_1.__decorate([
    Component({
        name: 'EmployeeManagement',
        components: {},
    })
], EmployeeManagement);
export default EmployeeManagement;
//# sourceMappingURL=EmployeeManagement.js.map