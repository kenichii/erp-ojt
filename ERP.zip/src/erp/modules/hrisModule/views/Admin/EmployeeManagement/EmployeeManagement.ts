import {Component, Vue} from 'vue-property-decorator';

@Component({
    name: 'EmployeeManagement',
    components: {},

})
export default class EmployeeManagement extends Vue {
}
