<template>
    <section>
        <router-view></router-view>
    </section>
</template>

<script lang="ts" src="./EmployeeManagement.ts"></script>

<style lang="scss" src="./EmployeeManagement.scss" scoped></style>
