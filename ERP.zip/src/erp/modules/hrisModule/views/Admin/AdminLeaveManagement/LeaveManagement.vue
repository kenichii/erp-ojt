<template>
    <section>
        <AdminLeaveManagement/>
    </section>
</template>

<script lang="ts" src="./LeaveManagement.ts"></script>
