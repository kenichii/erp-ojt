<template>
    <section>
        <TeamScheduleManagement></TeamScheduleManagement>
    </section>
</template>

<script lang="ts" src="./TeamSchedule.ts"></script>

