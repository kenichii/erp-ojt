<template>
    <section>
        <EmployeeScheduleComponent/>
    </section>
</template>

<script lang="ts" src="./EmployeeSchedule.ts"></script>


