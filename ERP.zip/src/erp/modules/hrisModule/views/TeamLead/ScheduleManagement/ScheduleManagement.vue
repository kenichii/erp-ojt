<template>
  <section>
      <ScheduleManagementComponent/>
  </section>
</template>

<script lang="ts" src="./ScheduleManagement.ts"></script>
