<template>

    <div class="card">
        <div class="card-content">
            <div class="columns">
                <div class="column is-2 ">
                    <div class="fullheight border-left is-medium">
                        <h1 class="head1 title  is-3">
                            19
                        </h1>
                        <h1 class="head1 subtitle is-6">
                            Total Leaves Accrued
                        </h1>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="fullheight border-left is-medium">
                        <h1 class="head1 title  is-3">
                            09
                        </h1>
                        <h1 class="head1 subtitle is-6">
                            Leaves Used
                        </h1>
                    </div>
                </div>
                <div class="column is-2 ">
                    <div class="fullheight border-left is-medium ">
                        <h1 class="head1 title  is-3">
                            10
                        </h1>
                        <h1 class="head1 subtitle is-6">
                            Leave Balance
                        </h1>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>

<script lang="ts" src="./LeavesCount.ts">
</script>

<style lang="scss" src="./LeavesCount.scss" scoped>

</style>
