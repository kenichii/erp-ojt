import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
let LeavesCount = class LeavesCount extends Vue {
};
LeavesCount = tslib_1.__decorate([
    Component({
        name: 'LeavesCount',
        components: {},
    })
], LeavesCount);
export default LeavesCount;
//# sourceMappingURL=LeavesCount.js.map