import {Component, Vue} from 'vue-property-decorator';

@Component({
    name: 'LeavesCount',
    components: {},
})
export default class LeavesCount extends Vue {
}
