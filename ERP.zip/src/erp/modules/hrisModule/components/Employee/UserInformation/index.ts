import ProfileInformation from './profileInformation/profileInformation.vue';
import ContactInformation from './ContactInformation/ContactInformation.vue';
import BusinessInformation from './BusinessInformation/BusinessInformation.vue';

export {
    ProfileInformation,
    ContactInformation,
    BusinessInformation,
};
