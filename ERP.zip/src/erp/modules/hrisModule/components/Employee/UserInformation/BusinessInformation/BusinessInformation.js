import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
let BusinessInformation = class BusinessInformation extends Vue {
};
BusinessInformation = tslib_1.__decorate([
    Component({
        name: "BusinessInformation",
        components: {},
        data: function () {
            return {
                editView: false
            };
        },
    })
], BusinessInformation);
export default BusinessInformation;
//# sourceMappingURL=BusinessInformation.js.map