import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
const count = 10;
let MedicalRecords = class MedicalRecords extends Vue {
};
MedicalRecords = tslib_1.__decorate([
    Component({
        name: 'MedicalRecords',
    })
], MedicalRecords);
export default MedicalRecords;
//# sourceMappingURL=MedicalRecords.js.map