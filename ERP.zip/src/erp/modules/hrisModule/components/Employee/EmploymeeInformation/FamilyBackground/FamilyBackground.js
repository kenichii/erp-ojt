import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
const count = 10;
let FamilyBackground = class FamilyBackground extends Vue {
};
FamilyBackground = tslib_1.__decorate([
    Component({
        name: 'FamilyBackground',
    })
], FamilyBackground);
export default FamilyBackground;
//# sourceMappingURL=FamilyBackground.js.map