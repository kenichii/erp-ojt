import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
const count = 10;
let GovernmentIds = class GovernmentIds extends Vue {
};
GovernmentIds = tslib_1.__decorate([
    Component({
        name: 'GovernmentIds',
        data: function () {
            return {
                editView: false
            };
        },
    })
], GovernmentIds);
export default GovernmentIds;
//# sourceMappingURL=GovernmentIds.js.map