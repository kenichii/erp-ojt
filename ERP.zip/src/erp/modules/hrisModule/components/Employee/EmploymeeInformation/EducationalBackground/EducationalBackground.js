import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
const count = 10;
let EducationalBackground = class EducationalBackground extends Vue {
};
EducationalBackground = tslib_1.__decorate([
    Component({
        name: 'EducationalBackground',
        data: function () {
            return {
                editView: false
            };
        },
    })
], EducationalBackground);
export default EducationalBackground;
//# sourceMappingURL=EducationalBackground.js.map