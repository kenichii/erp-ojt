import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
const count = 10;
let Skills = class Skills extends Vue {
};
Skills = tslib_1.__decorate([
    Component({
        name: 'Skills',
        data: function () {
            return {
                editView: false
            };
        },
    })
], Skills);
export default Skills;
//# sourceMappingURL=Skills.js.map