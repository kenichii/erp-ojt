import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
const count = 10;
let EmploymentHistory = class EmploymentHistory extends Vue {
};
EmploymentHistory = tslib_1.__decorate([
    Component({
        name: 'EmploymentHistory',
        data: function () {
            return {
                editView: false
            };
        },
    })
], EmploymentHistory);
export default EmploymentHistory;
//# sourceMappingURL=EmploymentHistory.js.map