export class EmploymentHistory {
    constructor(init) {
        Object.assign(this, init);
    }
}
//# sourceMappingURL=EmploymentHistory.js.map