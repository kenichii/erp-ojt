export class ContactDetailsModel {
    constructor(init) {
        Object.assign(this, init);
    }
}
//# sourceMappingURL=ContactDetailsModel.js.map