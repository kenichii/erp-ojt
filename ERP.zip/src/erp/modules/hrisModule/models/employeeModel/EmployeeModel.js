export class EmployeeModel {
    constructor(init) {
        this.contactDetails = [];
        this.educationalBackground = [];
        this.employmentHistory = [];
        this.governmentIDs = [];
        this.skills = [];
        Object.assign(this, init);
    }
}
//# sourceMappingURL=EmployeeModel.js.map