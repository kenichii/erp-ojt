export class GovernmentIDsModel {
    constructor(init) {
        Object.assign(this, init);
    }
}
//# sourceMappingURL=GovernmentIDsModel.js.map