export class SkillsModel {
    constructor(init) {
        Object.assign(this, init);
    }
}
//# sourceMappingURL=SkillsModel.js.map