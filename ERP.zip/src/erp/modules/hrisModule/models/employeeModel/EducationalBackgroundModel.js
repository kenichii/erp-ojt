export class EducationalBackgroundModel {
    constructor(init) {
        Object.assign(this, init);
    }
}
//# sourceMappingURL=EducationalBackgroundModel.js.map