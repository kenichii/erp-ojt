import Login from './Login/Login.vue';
import ForgotPassword from './ForgotPassword/ForgotPassword.vue';
import ResetPassword from './ForgotPassword/ResetPassword/ResetPassword.vue';
import StyleGuide from './StyleGuide/StyleGuide.vue';
import SelectModule from './SelectModule/SelectModule.vue';

export {
    Login,
    ForgotPassword,
    ResetPassword,
    StyleGuide,
    SelectModule,
};
