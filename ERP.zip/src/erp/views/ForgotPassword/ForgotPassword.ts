import {Component, Vue} from 'vue-property-decorator';

@Component({
    name: 'ForgotPassword',
    components: {
    },
})

export default class ForgotPassword extends Vue {
}
