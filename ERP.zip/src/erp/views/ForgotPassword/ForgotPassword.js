import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
let ForgotPassword = class ForgotPassword extends Vue {
};
ForgotPassword = tslib_1.__decorate([
    Component({
        name: 'ForgotPassword',
        components: {},
    })
], ForgotPassword);
export default ForgotPassword;
//# sourceMappingURL=ForgotPassword.js.map