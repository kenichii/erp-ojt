import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
let ConfirmReset = class ConfirmReset extends Vue {
};
ConfirmReset = tslib_1.__decorate([
    Component({
        name: 'ConfirmReset',
        components: {},
        data() {
            return {
                isCardModalActive: false,
            };
        },
    })
], ConfirmReset);
export default ConfirmReset;
//# sourceMappingURL=ConfirmReset.js.map