import * as tslib_1 from "tslib";
import { Component, Vue } from 'vue-property-decorator';
let NotFound = class NotFound extends Vue {
};
NotFound = tslib_1.__decorate([
    Component({
        name: 'NotFound',
        components: {},
    })
], NotFound);
export default NotFound;
//# sourceMappingURL=notfound.js.map