<template>
    <div>
       not found
    </div>
</template>

<script lang='ts' src='./notfound.ts'/>