module.exports = {
    plugins: {
        autoprefixer: {}
    }
};
