module.exports = {
  pwa: {
    themeColor: '#1915DC'
  }
}